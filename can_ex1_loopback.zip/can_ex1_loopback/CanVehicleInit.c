/*
 * CanVehicleInit.c
 *
 *  Created on: 2023��4��5��
 *      Author: jiangtao
 */

#include "CanVehicleInit.h"

CAN_UDS_MB_t UdsMB;
CAN_VEHICLE_MB_t VCanMB;

void CanVehicle_ModuleInit(uint32_t Bps)
{
    //myCAN0 initialization
    CAN_initModule(CAN_VEHCILE_BASE);

    // Refer to the Driver Library User Guide for information on how to set
    // tighter timing control. Additionally, consult the device data sheet
    // for more information about the CAN module clocking.
    //
    CAN_setBitRate(CAN_VEHCILE_BASE, DEVICE_SYSCLK_FREQ, Bps, 20);
    //CAN_setBitTiming(CAN0_BASE, 9, 0, 14, 7, 3);

}

void CanVehicle_UdsMailBoxInit(CAN_UDS_MB_t *pUds)
{

    CAN_setupMessageObject(CAN_VEHCILE_BASE,
                           pUds->TesterPhyMbID,
                           pUds->TesterPhyMsgID,
                           pUds->TesterPhyMsgType,
                           CAN_MSG_OBJ_TYPE_RX,
                           0,
                           0,
                           CAN_UDS_MAILBOX_DATA_LENGTH);

    CAN_setupMessageObject(CAN_VEHCILE_BASE,
                           pUds->TesterFuncMbID,
                           pUds->TesterFuncMsgID,
                           pUds->TesterFuncMsgType,
                           CAN_MSG_OBJ_TYPE_RX,
                           0,
                           0,
                           CAN_UDS_MAILBOX_DATA_LENGTH);


    CAN_setupMessageObject(CAN_VEHCILE_BASE,
                           pUds->EcuPhyMbID,
                           pUds->EcuPhyMsgID,
                           pUds->EcuPhyMsgType,
                           CAN_MSG_OBJ_TYPE_TX,
                           0,
                           0,
                           CAN_UDS_MAILBOX_DATA_LENGTH);
}

void CanVehicle_CarMailBoxInit(CAN_VEHICLE_MB_t *pCar)
{
    uint16_t i=0;

    for(i=0;i<pCar->RxMsgNum;i++)
    {
        CAN_setupMessageObject(CAN_VEHCILE_BASE,
                               pCar->RxMailBoxID[i],
                               pCar->RxMsgID[i],
                               pCar->RxMsgFrameType[i],
                               CAN_MSG_OBJ_TYPE_RX,
                               0,
                               0,
                               8);
    }

    for(i=0;i<pCar->TxMsgNum;i++)
    {
        CAN_setupMessageObject(CAN_VEHCILE_BASE,
                               pCar->TxMailBoxID[i],
                               pCar->TxMsgID[i],
                               pCar->TxMsgFrameType[i],
                               CAN_MSG_OBJ_TYPE_TX,
                               0,
                               0,
                               8);
    }

}

void CanVehicle_Init(uint32_t Bps,CAN_UDS_MB_t *pUds,CAN_VEHICLE_MB_t *pCar)
{
    CanVehicle_ModuleInit(Bps);
    CanVehicle_UdsMailBoxInit(pUds);
    CanVehicle_CarMailBoxInit(pCar);
    CAN_startModule(CAN_VEHCILE_BASE);
}


void CanVehicle_Test(uint16_t RxMbId,uint16_t TxMbId)
{
    uint16_t RxData[8]={0,0,0,0,0,0,0,0};
    uint16_t TxData[8]={0,0,0,0,0,0,0,0};
    if(CAN_readMessage(CAN_VEHCILE_BASE,RxMbId,RxData) == 1)
    {
        if(RxData[0] == 0xFF)
        {
            TxData[0] = 0xFF;
            TxData[1] = 9;
            TxData[2] = 2;
            TxData[3] = 3;
            TxData[4] = 4;
            TxData[5] = 5;
            TxData[6] = 6;
            TxData[7] = 9;
            CAN_sendMessage(CAN_VEHCILE_BASE,TxMbId,8,TxData);
        }
    }

}

void CanVehicle_UdsSendMessage(uint32_t msgID,const uint16_t *msgData,uint16_t msgLen)
{
    if(msgID == UdsMB.EcuPhyMsgID)
    {
        CAN_sendMessage_updateDLC(CAN_VEHCILE_BASE,UdsMB.EcuPhyMbID,msgLen,msgData);
    }

}

uint16_t CanVehicle_UdsRecvMassage(void)
{

    if(CAN_readMessageWithID(CAN_VEHCILE_BASE,
                             UdsMB.TesterPhyMbID,
                             &UdsMB.TesterPhyMsgType,
                             &UdsMB.TesterPhyMsgID,
                             &UdsMB.TesterPhyMsgData[0]))
    {
        return 1;
    }
    else if(CAN_readMessageWithID(CAN_VEHCILE_BASE,
                                  UdsMB.TesterFuncMbID,
                                  &UdsMB.TesterFuncMsgType,
                                  &UdsMB.TesterFuncMsgID,
                                  &UdsMB.TesterFuncMsgData[0]))
    {
        return 2;
    }
    else
    {
        return 0;
    }
}
