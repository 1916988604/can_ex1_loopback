//#############################################################################
//
// FILE:   can_ex1_loopback.c
//
// TITLE:   CAN External Loopback Example
//
//! \addtogroup driver_example_list
//! <h1> CAN External Loopback </h1>
//!
//! This example shows the basic setup of CAN in order to transmit and receive
//! messages on the CAN bus.  The CAN peripheral is configured to transmit
//! messages with a specific CAN ID.  A message is then transmitted once per
//! second, using a simple delay loop for timing.  The message that is sent is
//! a 2 byte message that contains an incrementing pattern.
//!
//! This example sets up the CAN controller in External Loopback test mode.
//! Data transmitted is visible on the CANTXA pin and is received internally
//! back to the CAN Core. Please refer to details of the External Loopback
//! Test Mode in the CAN Chapter in the Technical Reference Manual. Refer 
//! to [Programming Examples and Debug Strategies for
//! the DCAN Module](www.ti.com/lit/SPRACE5) for useful information about
//! this example
//!
//! \b External \b Connections \n
//!  - None.
//!
//! \b Watch \b Variables \n
//!  - msgCount - A counter for the number of successful messages received
//!  - txMsgData - An array with the data being sent
//!  - rxMsgData - An array with the data that was received
//!
//
//#############################################################################
//
//
// $Copyright:
// Copyright (C) 2023 Texas Instruments Incorporated - http://www.ti.com/
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
// 
//   Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// 
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the   
//   distribution.
// 
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $
//#############################################################################

//
// Included Files
//
#include "driverlib.h"
#include "device.h"
#include "board.h"
#include "CanVehicleInit.h"
#include "UdsIf.h"
#include "Dsp2803x.h"
//
// Defines
//
#define MSG_DATA_LENGTH    2

//
// Globals
//
//volatile unsigned long msgCount = 0;
void System_CpuTimerInit(uint32_t CpuTimerBase,uint32_t period_us)
{
    uint32_t temp;

    //
    // Initialize timer period:
    //
    temp = (uint32_t)(DEVICE_SYSCLK_FREQ / 1000000 * period_us);
    CPUTimer_setPeriod(CpuTimerBase, temp);

    //
    // Set pre-scale counter to divide by 1 (SYSCLKOUT):
    //
    CPUTimer_setPreScaler(CpuTimerBase, 0);

    //
    // Initializes timer control register. The timer is stopped, reloaded,
    // free run disabled, and interrupt enabled.
    // Additionally, the free and soft bits are set
    //
    CPUTimer_stopTimer(CpuTimerBase);
    CPUTimer_reloadTimerCounter(CpuTimerBase);
    CPUTimer_setEmulationMode(CpuTimerBase,
                              CPUTIMER_EMULATIONMODE_STOPAFTERNEXTDECREMENT);
    CPUTimer_enableInterrupt(CpuTimerBase);

    CPUTimer_startTimer(CpuTimerBase);
}

__interrupt void INT_CpuTimer0_ISR(void)
{
    static uint32_t Counter = 0;

    Counter++;
    if(Counter % 2 == 0)
    {
        Diagnostic_1msTimer();
    }
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP1);
}
//
// Main
//
void main(void)
{
    //
    // Initialize device clock and peripherals
    //
    Device_init();

    //
    // Initialize GPIO and configure GPIO pins for CANTX/CANRX
    //
    Device_initGPIO();

    //PinMux_init();

    //
    // Board initialization
    //
   Board_init();
    UdsMB.TesterFuncMsgID = 0x1ff;
    UdsMB.TesterPhyMsgID  = 0x200;
    UdsMB.EcuPhyMsgID     = 0x201;

    UdsMB.TesterFuncMbID  = 14;
    UdsMB.TesterPhyMbID   = 15;
    UdsMB.EcuPhyMbID      = 31;

    UdsMB.TesterFuncMsgType = CAN_MSG_FRAME_STD;
    UdsMB.TesterPhyMsgType  = CAN_MSG_FRAME_STD;
    UdsMB.EcuPhyMsgType     = CAN_MSG_FRAME_STD;

    VCanMB.RxMsgNum = 1;
    VCanMB.TxMsgNum = 1;

    VCanMB.RxMsgID[0] = 0x100;
    VCanMB.RxMailBoxID[0] = 0;
    VCanMB.RxMsgFrameType[0] = CAN_MSG_FRAME_STD;
    VCanMB.TxMsgID[0] = 0x101;
    VCanMB.TxMailBoxID[0] = 16;
    VCanMB.TxMsgFrameType[0] = CAN_MSG_FRAME_STD;




    //
    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    //
    Interrupt_initModule();

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    //
    Interrupt_initVectorTable();

    Interrupt_register(INT_TIMER0, &INT_CpuTimer0_ISR);
    Interrupt_enable(INT_TIMER0);
    CanVehicle_Init(CAN_VEHCILE_BITRATE,&UdsMB,&VCanMB);

    System_CpuTimerInit(CPUTIMER0_BASE,500);
    //
    // Enable Global Interrupt (INTM) and realtime interrupt (DBGM)
    //
    EINT;
    ERTM;

    UdsIf.TesterFuncMsgID = 0x1ff;
    UdsIf.TesterPhyMsgID  = 0x200;
    UdsIf.EcuPhyMsgID     = 0x201;
    Diagnostic_InitConfig(&UdsIf);
  /* Write your code here */
    while(1)
    {
        //CanVehicle_Test(0,16);
        Diagnostic_RecvFrame();
        Diagnostic_Proc();
    }
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END DiagnosticDemo */
/*
** ###################################################################
**
**     This file was created by Processor Expert 3.02 [04.44]
**     for the Freescale HCS12 series of microcontrollers.
**
** ###################################################################
*/
