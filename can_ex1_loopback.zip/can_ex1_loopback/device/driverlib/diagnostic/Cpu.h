/*
 * Cpu.h
 *
 *  Created on: 2023��6��26��
 *      Author: DELL
 */

#ifndef DIAGNOSTIC_CPU_H_
#define DIAGNOSTIC_CPU_H_


#include "driverlib.h"
typedef uint16_t      word;
typedef uint16_t      byte;
typedef uint32_t      dword;

#define TRUE        1
#define FALSE       0


#endif /* DIAGNOSTIC_CPU_H_ */
