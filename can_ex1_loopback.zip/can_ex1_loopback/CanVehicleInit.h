/*
 * CanVehicleInit.h
 *
 *  Created on: 2023��4��5��
 *      Author: jiangtao
 */

#ifndef BSW_BOARD_COMM_CANVEHICLEINIT_H_
#define BSW_BOARD_COMM_CANVEHICLEINIT_H_
#include "driverlib.h"
#include "device.h"
#include "board.h"
#include "Dsp2803x.h"

#define CAN_VEHCILE_BASE                        CANA_BASE
#define CAN_VEHCILE_BITRATE                     500000

#define CAN_VEHCILE_RECV_ID                     0x555
#define CAN_VEHCILE_SEND_ID                     0x554

#define CAN_UDS_TESTER_FUNC_MAILBOX_ID             14
#define CAN_UDS_TESTER_PHY_MAILBOX_ID              15
#define CAN_UDS_ECU_PHY_MAILBOX_ID                 31

#define CAN_UDS_MAILBOX_DATA_LENGTH         8

typedef struct
{
    uint32_t TesterFuncMsgID;
    uint32_t TesterPhyMsgID;
    uint32_t EcuPhyMsgID;

    uint32_t TesterFuncMbID;
    uint32_t TesterPhyMbID;
    uint32_t EcuPhyMbID;

    CAN_MsgFrameType TesterFuncMsgType;
    CAN_MsgFrameType TesterPhyMsgType;
    CAN_MsgFrameType EcuPhyMsgType;

    uint16_t TesterFuncMsgData[8];
    uint16_t TesterPhyMsgData[8];
    uint16_t EcuPhyMsgData[8];

} CAN_UDS_MB_t;

typedef struct
{
    uint32_t TxMsgID[12];
    uint16_t TxMailBoxID[12];
    CAN_MsgFrameType TxMsgFrameType[12];
    uint32_t RxMsgID[12];
    uint16_t RxMailBoxID[12];
    CAN_MsgFrameType RxMsgFrameType[12];
    uint16_t TxData[8];
    uint16_t RxData[8];

    uint16_t TxMsgNum;
    uint16_t RxMsgNum;

} CAN_VEHICLE_MB_t;

extern CAN_UDS_MB_t UdsMB;
extern CAN_VEHICLE_MB_t VCanMB;

extern void CanVehicle_Init(uint32_t Bps,CAN_UDS_MB_t *pUds,CAN_VEHICLE_MB_t *pCar);

extern void CanVehicle_Test(uint16_t RxMbId,uint16_t TxMbId);

extern void CanVehicle_UdsSendMessage(uint32_t msgID,const uint16_t *msgData,uint16_t msgLen);
extern uint16_t CanVehicle_UdsRecvMassage(void);

#endif /* BSW_BOARD_COMM_CANVEHICLEINIT_H_ */
