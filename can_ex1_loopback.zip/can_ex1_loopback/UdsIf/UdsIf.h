/*
 * UdsIf.h
 *
 *  Created on: 2023��7��3��
 *      Author: 36208
 */

#ifndef BSW_SERV_COMM_UDSIF_UDSIF_H_
#define BSW_SERV_COMM_UDSIF_UDSIF_H_

#include "diagnostic.h"

typedef struct
{
    uint32_t TesterFuncMsgID;
    uint32_t TesterPhyMsgID;
    uint32_t EcuPhyMsgID;
} UDS_IF_DATA_t;

extern UDS_IF_DATA_t UdsIf;

extern void Diagnostic_RecvFrame(void);
extern void Diagnostic_InitConfig(UDS_IF_DATA_t *pUds);

#endif /* BSW_SERV_COMM_UDSIF_UDSIF_H_ */
