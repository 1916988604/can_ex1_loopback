/*
 * UdsIf.c
 *
 *  Created on: 2023��7��3��
 *      Author: 36208
 */
#include "UdsIf.h"
#include "CanVehicleInit.h"

UDS_IF_DATA_t UdsIf;

void ForceReset(void)
{
   // ServSys_ResetDevice();
}

void SystemReset(EcuResetType resetType)
{
    if(resetType == 1)//Ӳ����λ
    {
        ForceReset();
    }
    else if(resetType == 2)//key-off-on��λ
    {
        //ForceReset();��֧�ָ�λ����ʱ��������������
    }
    else if(resetType == 3)//������λ
    {
        ForceReset();
    }
}

void CommulicatonControl(CommulicationType type, communicationParam param)
{
    bool rxenable = ((type & 0x02) == 0x00);//��������
    bool txenable = ((type & 0x01) == 0x00);//��������
    bool CtrlNmMessage = ((param & 0x02) == 0x02);//�������������Ϣ
    bool CtrlAppMessage = ((param & 0x01) == 0x01);//����Ӧ�ñ���

    if(CtrlNmMessage)
    {
        //NMSetCommulicationEnable(txenable, rxenable);

    }

    if(CtrlAppMessage)
    {
        //AppSetMsgEnable(txenable, rxenable);
    }
}

/*uint32_t SeedToKeyDemo(uint32_t seed)
{
    return 0x12345678;//���ĳһ������İ�ȫ�㷨
}*/
void SeedToKeyDemo(uint8_t *seed,uint8_t *key,uint8_t size)
{
    uint8_t i;
    for(i = 0; i < size; i++)
    {
        *(key+i)=*(seed+i)+1;
    }
}

uint16_t TestF180Data = 0xF180;
uint8_t TestCurrentTemp = 0x40;
uint16_t CurrentSpeed = 0x0895;
uint8_t CurrentVoltage = 135;

uint8_t IO9826_MixMtrCtrl;
uint8_t IoControl_9826(uint8_t ctrl, uint8_t param) {
    if(ctrl == 0) {
        IO9826_MixMtrCtrl = 2;
    }
    else if(ctrl == 1)
    {
        IO9826_MixMtrCtrl = 2;
    } else if(ctrl == 2)
    {

    }else if(ctrl == 3)
    {
        if(param == 0)
        {
            IO9826_MixMtrCtrl = 0;
        }
        else if(param == 1)
        {
            IO9826_MixMtrCtrl = 1;
        }
    }
    return IO9826_MixMtrCtrl;
}

uint8_t NMGetLimpHome(void)
{
     if (1)
     {
        return 2;//failed
     }
     else
     {
        return 0;//passed
     }
}

byte Diagnostic_SendFrame(uint32_t ID, byte *array, byte length)
{
    CanVehicle_UdsSendMessage(ID,array,length);
    return 1;
}
void Diagnostic_RecvFrame(void)
{
    uint16_t Temp = CanVehicle_UdsRecvMassage();
    if(Temp == 1)
    {
        Diagnostic_RxFrame(UdsMB.TesterPhyMsgID,&UdsMB.TesterPhyMsgData[0],UdsMB.TesterPhyMsgType,8,0);
    }
    else if(Temp == 2)
    {
        Diagnostic_RxFrame(UdsMB.TesterFuncMsgID,&UdsMB.TesterFuncMsgData[0],UdsMB.TesterFuncMsgType,8,0);
    }
}

void Diagnostic_InitConfig(UDS_IF_DATA_t *pUds)
{
    Diagnostic_Init(pUds->TesterPhyMsgID, pUds->EcuPhyMsgID , pUds->TesterFuncMsgID, 0xA00 , 1024 , Diagnostic_SendFrame,0x0032,0x00C8);
    //********************************** service 10*****************************************//
    //Diagnostic_Set2ndReqAndResID(0x18DA19F9, 0x18DAF919 , 0x18DBFFF9);

    InitSetSessionSupportAndSecurityAccess(TRUE,0x10,LEVEL_ZERO,LEVEL_ZERO,LEVEL_ZERO,LEVEL_ZERO,LEVEL_ZERO,LEVEL_ZERO);
    InitSetSessionControlParam(TRUE , TRUE , TRUE , FALSE , FALSE , TRUE);

    //********************************** service 27*****************************************//

    InitAddSecurityAlgorithm(LEVEL_ONE,SeedToKeyDemo,0x01,0x02, NULL ,3 , 10000, SUB_PROGRAM | SUB_EXTENDED,4);
    InitFactorySecuriyAlgorithm();
    //InitAddSecurityAlgorithm(LEVEL_THREE,HD10SeedToKey,0x07,0x08, NULL ,3 , 10000, SUB_PROGRAM);
    InitSetSessionSupportAndSecurityAccess(TRUE,0x27,LEVEL_UNSUPPORT,LEVEL_ZERO,LEVEL_ZERO,LEVEL_UNSUPPORT,LEVEL_UNSUPPORT,LEVEL_UNSUPPORT);

    //********************************** service 3E*****************************************//

    InitSetSessionSupportAndSecurityAccess(TRUE,0x3E,LEVEL_ZERO,LEVEL_ZERO,LEVEL_ZERO,LEVEL_ZERO,LEVEL_ZERO,LEVEL_ZERO);
    InitSetTesterPresentSupress(TRUE);
      //********************************** service 11*****************************************//


    InitSetSessionSupportAndSecurityAccess(TRUE,0x11,LEVEL_UNSUPPORT,LEVEL_ZERO,LEVEL_ZERO,LEVEL_UNSUPPORT,LEVEL_ZERO,LEVEL_ZERO);
    InitSetSysResetParam(TRUE , FALSE , FALSE , FALSE , FALSE , SystemReset , TRUE);

       //********************************** service 28*****************************************//

    InitSetSessionSupportAndSecurityAccess(TRUE,0x28,LEVEL_UNSUPPORT,LEVEL_ZERO,LEVEL_ZERO,LEVEL_UNSUPPORT,LEVEL_ZERO,LEVEL_ZERO);
    InitSetCommControlParam(TRUE , TRUE , TRUE , TRUE , TRUE , TRUE , TRUE , CommulicatonControl , TRUE);
     //********************************** service 85*****************************************//

    InitSetSessionSupportAndSecurityAccess(TRUE,0x85,LEVEL_UNSUPPORT,LEVEL_ZERO,LEVEL_ZERO,LEVEL_UNSUPPORT,LEVEL_ZERO,LEVEL_ZERO);
    InitSetDTCControlSupress(TRUE);
      //********************************** service 22  2E  2F*****************************************//

    InitAddDID(0xF180, 8 , NULL ,  EEPROM_DID , NULL , READONLY , 0 ,TRUE);//ֻ�ܶ���DID,�洢��EEPROM�У�������������ʱд
    InitAddDID(0xF190, 2, NULL , EEPROM_DID , NULL , READWRITE , 0 , FALSE);//�ɶ�д��DID���洢��EEPROM��
    InitAddDID(0x9816,1 , &TestCurrentTemp , REALTIME_DID , NULL , READONLY , 0 ,FALSE);//ֻ��DID��ʵʱ����(�籨�����ݵ�)��
    InitAddDID(0x9823,1 , &IO9826_MixMtrCtrl , IO_DID , IoControl_9826 , READWRITE , 0 ,FALSE);//�ɶ�д��IO DID���ȿ���ͨ��22�����ȡ��Ҳ����ͨ��2F�������
    InitAddDID(0x9826,1 , NULL , IO_DID , IoControl_9826 , WRITEONLY , 0 , FALSE);//ֻ��ͨ��2F���Ƶ�IO DID��
    #if 1
    InitSetCanDriverVersionDID(0x0A01);
    InitSetCanNMVersionDID(0x0A02);
    InitSetCanDiagnosticVersionDID(0x0A03);
    InitSetCanDataBaseVersionDID(0x0A04);
    InitSetCurrentSessionDID(0xF186);
    #endif

    InitSetSessionSupportAndSecurityAccess(TRUE,0x22,LEVEL_ZERO,LEVEL_ZERO,LEVEL_ZERO,LEVEL_ZERO,LEVEL_ZERO,LEVEL_ZERO);

    InitSetSessionSupportAndSecurityAccess(TRUE,0x2F,LEVEL_UNSUPPORT,LEVEL_UNSUPPORT,LEVEL_ONE,LEVEL_UNSUPPORT,LEVEL_UNSUPPORT,LEVEL_UNSUPPORT);

    InitSetSessionSupportAndSecurityAccess(TRUE,0x2E,LEVEL_ZERO,LEVEL_ONE,LEVEL_ONE,LEVEL_UNSUPPORT,LEVEL_UNSUPPORT,LEVEL_UNSUPPORT);

    //********************************** service 19*****************************************//
    InitSetSessionSupportAndSecurityAccess(TRUE,0x19,LEVEL_ZERO,LEVEL_UNSUPPORT,LEVEL_ZERO,LEVEL_ZERO,LEVEL_UNSUPPORT,LEVEL_ZERO);

    InitSetDTCAvailiableMask(0x09);             //  ֧�ֵĹ���״̬����
    InitAddDTC(0x910223,NMGetLimpHome,10, 1 ,LEVEL_C);          //limphome
    //********************************** service 14*****************************************//

    InitSetSessionSupportAndSecurityAccess(TRUE,0x14,LEVEL_ZERO,LEVEL_UNSUPPORT,LEVEL_ZERO,LEVEL_ZERO,LEVEL_UNSUPPORT,LEVEL_ZERO);
    InitAddDTCGroup(0x00FFFFFF);

    //**********************************snaptshot*****************************************//
    InitAddDTCSnapShot(0x01 , 0x9102 , &CurrentSpeed , 2);
    InitAddDTCSnapShot(0x01 , 0x9103 , &CurrentVoltage , 1);
    InitAddDTCSnapShot(0x02 , 0x9105 , &CurrentVoltage , 3);
    InitAddDTCSnapShot(0x04 , 0x9106 , &CurrentVoltage , 1);
    InitAddDTCSnapShot(0x04 , 0x9108 , &CurrentVoltage , 1);

    InitSetAgingCounterRecordNumber(3);
    InitSetAgedCounterRecordNumber(4);
    InitSetOccurrenceCounterRecordNumber(1);
    InitSetPendingCounterRecordNumber(2);

    Diagnostic_LoadAllData();

    Diagnostic_SetNLParam(70, 150, 150, 70, 70, 70, 8, 20, 0xFF);
}

