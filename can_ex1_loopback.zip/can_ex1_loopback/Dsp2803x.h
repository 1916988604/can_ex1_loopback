/*
 * Cpu.h
 *
 *  Created on: 2023��7��3��
 *      Author: 36208
 */

#ifndef BSW_SERV_COMM_UDSIF_CPU_H_
#define BSW_SERV_COMM_UDSIF_CPU_H_

#include "stdint.h"
#include "Types.h"
#include "hw_types.h"
#include "stdbool.h"
#include "stw_dataTypes.h"

#define FALSE 0
#define TRUE  1

typedef uint16_t uint8_t;
typedef uint16_t byte;
typedef uint16_t word;
typedef uint32_t dword;

#endif /* BSW_SERV_COMM_UDSIF_CPU_H_ */
